// Obtiene el botón por su ID
const boton = document.getElementById('pruebame-btn');

// Añade un evento de clic al botón
boton.addEventListener('click', function() {
    // Redirige al archivo 'eres_mi_sanValentin.html'
    window.location.href = 'eres_mi_sanValentin.html';
});

